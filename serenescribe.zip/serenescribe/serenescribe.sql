-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 04:59 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `serenescribe`
--

-- --------------------------------------------------------

--
-- Table structure for table `block_list`
--

CREATE TABLE `block_list` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `blocked_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `block_list`
--

INSERT INTO `block_list` (`id`, `user_id`, `blocked_user_id`) VALUES
(13, 13, 16);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `comment`, `created_at`) VALUES
(49, 16, 14, 'proud of you 💓', '2023-06-08 22:04:00'),
(51, 15, 14, 'hits deep </3', '2023-06-08 22:07:34'),
(52, 16, 15, 'love that for u!!', '2023-06-08 22:13:08'),
(53, 15, 15, 'got me sobbing 🥹', '2023-06-08 22:13:35'),
(54, 17, 15, 'BE A DANDELION!!', '2023-06-08 22:13:54'),
(55, 18, 13, 'thank uuu <3', '2023-06-08 22:14:57'),
(56, 17, 13, 'tru tru', '2023-06-08 22:15:11'),
(57, 17, 13, 'hello', '2023-06-09 12:32:22');

-- --------------------------------------------------------

--
-- Table structure for table `follow_list`
--

CREATE TABLE `follow_list` (
  `id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `follow_list`
--

INSERT INTO `follow_list` (`id`, `follower_id`, `user_id`) VALUES
(77, 14, 13),
(78, 15, 13),
(79, 15, 14),
(80, 13, 14),
(81, 13, 15),
(82, 14, 15),
(84, 17, 13),
(85, 17, 14),
(86, 17, 15),
(87, 18, 13),
(88, 18, 14);

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `post_id`, `user_id`) VALUES
(93, 16, 14),
(94, 15, 14),
(95, 18, 15),
(96, 17, 15),
(97, 16, 15),
(98, 15, 15),
(100, 17, 13),
(103, 19, 13);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `msg` text NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `from_user_id`, `to_user_id`, `msg`, `read_status`, `created_at`) VALUES
(41, 15, 13, 'hiii, how are you??', 1, '2023-06-08 22:11:23'),
(42, 15, 14, 'heyy, just wanted to say i love your post!!', 1, '2023-06-08 22:11:47'),
(43, 14, 15, 'thank youu!! love yours too :3', 0, '2023-06-08 22:16:17'),
(44, 13, 15, 'hi hi! im doing better, thank u for askinn 💓', 0, '2023-06-08 22:23:10'),
(45, 13, 15, 'u??', 0, '2023-06-08 22:23:15');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `from_user_id` int(11) NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 0,
  `post_id` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `to_user_id`, `message`, `created_at`, `from_user_id`, `read_status`, `post_id`) VALUES
(105, 13, 'started following you !', '2023-06-08 22:06:30', 14, 1, '0'),
(106, 13, 'commented on your post', '2023-06-08 22:07:34', 14, 1, '15'),
(107, 13, 'liked your post !', '2023-06-08 22:08:43', 14, 2, '16'),
(108, 13, 'liked your post !', '2023-06-08 22:08:45', 14, 1, '15'),
(109, 13, 'started following you !', '2023-06-08 22:10:54', 15, 1, '0'),
(110, 14, 'started following you !', '2023-06-08 22:10:55', 15, 1, '0'),
(111, 14, 'liked your post !', '2023-06-08 22:12:51', 15, 1, '17'),
(112, 13, 'liked your post !', '2023-06-08 22:12:53', 15, 2, '16'),
(113, 13, 'liked your post !', '2023-06-08 22:12:55', 15, 1, '15'),
(114, 13, 'commented on your post', '2023-06-08 22:13:08', 15, 2, '16'),
(115, 13, 'commented on your post', '2023-06-08 22:13:35', 15, 1, '15'),
(116, 14, 'commented on your post', '2023-06-08 22:13:54', 15, 1, '17'),
(117, 14, 'started following you !', '2023-06-08 22:14:39', 13, 1, '0'),
(118, 15, 'started following you !', '2023-06-08 22:14:39', 13, 0, '0'),
(119, 15, 'liked your post !', '2023-06-08 22:14:46', 13, 0, '18'),
(120, 15, 'commented on your post', '2023-06-08 22:14:57', 13, 0, '18'),
(121, 14, 'commented on your post', '2023-06-08 22:15:11', 13, 1, '17'),
(122, 14, 'liked your post !', '2023-06-08 22:15:14', 13, 1, '17'),
(123, 15, 'started following you !', '2023-06-08 22:15:39', 14, 0, '0'),
(124, 13, 'started following you !', '2023-06-09 10:56:48', 16, 1, '0'),
(125, 15, 'unliked your post !', '2023-06-09 11:20:51', 13, 0, '18'),
(126, 15, 'liked your post !', '2023-06-09 11:20:52', 13, 0, '18'),
(127, 15, 'unliked your post !', '2023-06-09 12:31:07', 13, 0, '18'),
(128, 14, 'commented on your post', '2023-06-09 12:32:22', 13, 0, '17'),
(129, 15, 'liked your post !', '2023-06-09 12:35:43', 13, 0, '18'),
(130, 15, 'unliked your post !', '2023-06-09 12:35:44', 13, 0, '18'),
(131, 13, 'started following you !', '2023-06-09 12:45:03', 17, 0, '0'),
(132, 14, 'started following you !', '2023-06-09 12:45:04', 17, 0, '0'),
(133, 15, 'started following you !', '2023-06-09 12:45:05', 17, 0, '0'),
(134, 13, 'started following you !', '2023-06-09 12:50:40', 18, 0, '0'),
(135, 14, 'started following you !', '2023-06-09 12:50:41', 18, 0, '0'),
(136, 16, 'blocked you', '2023-06-09 13:51:38', 13, 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_img` text NOT NULL,
  `post_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `post_img`, `post_text`, `created_at`) VALUES
(15, 13, '1686261473soa.png', 'this line in Song of Achilles <3', '2023-06-08 21:57:53'),
(17, 14, '1686262162daisy.jpg', 'this^^', '2023-06-08 22:09:22'),
(18, 15, '1686262360teytey.jpg', 'just a reminder 😊', '2023-06-08 22:12:40'),
(19, 13, '1686314233semicolon.png', 'got this tattoo recenlty :))', '2023-06-09 12:37:13'),
(20, 17, '1686314800Mental Health Benefits of Art _ Custom Canvas Prints.jpg', 'me', '2023-06-09 12:46:40'),
(21, 18, '1686315155charlalu.jpg', 'drew this', '2023-06-09 12:52:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `profile_pic` text NOT NULL DEFAULT 'default_profile.jpg',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ac_status` int(11) NOT NULL COMMENT '0=not verified,1=active,2=blocked'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `username`, `password`, `profile_pic`, `created_at`, `updated_at`, `ac_status`) VALUES
(13, 'Theatots', 'Narcs', 0, 'theanarca@gmail.com', 'theatots', '827ccb0eea8a706c4c34a16891f84e7b', '1686260200teytey.jpg', '2023-06-08 17:48:57', '2023-06-08 21:36:40', 0),
(14, 'Blants', 'Balab', 2, 'blants@gmail.com', 'blants', '1e01ba3e07ac48cbdab2d3284d1dd0fa', '1686262188blants.jpg', '2023-06-08 22:02:09', '2023-06-08 22:09:48', 0),
(15, 'Janeyney', 'Domi', 2, 'janey@gmail.com', 'janeya', '84d2004bf28a2095230e8e14993d398d', '1686262451janeyney.jpg', '2023-06-08 22:10:40', '2023-06-08 22:14:11', 0),
(16, 'euni', 'nicnic', 2, 'euni@gmail.com', 'eunieuni', 'b208b961b28feb0ff7e2a3bd5e03bc78', '1686308378euni.jpg', '2023-06-09 10:56:32', '2023-06-09 10:59:38', 0),
(17, 'Erlalu', 'Cancan', 1, 'erlalu@gmail.com', 'elalu', '4d240e211b9816ba0e751d7e637739d7', '1686314931erlalu.jpg', '2023-06-09 12:44:46', '2023-06-09 12:48:51', 0),
(18, 'Charlalu', 'Cuntay', 1, 'charl@gmail.com', 'Charlalu', 'dba31bb5c75992690f20c2d3b370ec7c', '1686315138charlalu.jpg', '2023-06-09 12:50:25', '2023-06-09 12:52:18', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `block_list`
--
ALTER TABLE `block_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `follow_list`
--
ALTER TABLE `follow_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `block_list`
--
ALTER TABLE `block_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `follow_list`
--
ALTER TABLE `follow_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
