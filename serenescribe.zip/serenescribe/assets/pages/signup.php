<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap");

        * {
            margin: 0;
            padding: 0;
        }

        /**-- background image --*/
        .background {
            background-image: url(assets/images/background.jpg);
        }

        /**-- footer --**/
        footer {
            position: relative;
            width: cover;
            background: #3586ff;
            min-height: 200px;
            padding: 20px 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            Flex-direction: column;
            margin-top: 2%;
        }

        footer .social_icon,
        footer .menu {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 10px 0;
            flex-wrap: wrap;
        }
        footer .social_icon li,
        footer .menu li {
            list-style: none;
        }

        footer .social_icon li,
        footer .menu li {
            font-size: 2em;
            color: #fff;
            margin: 0 10px;
            display: inline-block;
            transition: 0.5s;
        }

        footer .social_icon li:hover {
            transform: translateY(-10px);
        }

        footer .menu li {
            font-size: 1.2em;
            color: #fff;
            margin: 0 10px;
            display: inline-block;
            text-decoration: none;
            opacity: 0.75;
        }

        footer .menu li:hover {
            opacity: 1;
        }

        footer p {
            color: #fff;
            text-align: center;
            margin-top: 15px;
            margin-bottom: 10px;
            font-size: 1.1em;
        }

        footer .wave {
            position: absolute;
            top: -100px;
            left: 0;
            width: 100%;
            height: 100px;
            background: url(images/wave.png);
            background-size: 1000px 100px;
        }

        footer .wave#wave1 {
            z-index: 1000;
            opacity: 1;
            bottom: 0;
            animation: animateWave 7s linear infinite;
        }

        footer .wave#wave2 {
            z-index: 999;
            opacity: 0.5;
            bottom: 10px;
            animation: animateWave_02 7s linear infinite;
        }

        footer .wave#wave3 {
            z-index: 1000;
            opacity: 0.2;
            bottom: 15px;
            animation: animateWave_02 5s linear infinite;
        }

        footer .wave#wave4 {
            z-index: 999;
            opacity: 0.7;
            bottom: 20px;
            animation: animateWave_02 5s linear infinite;
        }

        @keyframes animateWave {
            0% {
        background-position-x: 1000px;
            }
            100% {
        background-position-x: 0px;
            }
        }

        @keyframes animateWave_02 {
            0% {
        background-position-x: 0px;
            }
            100% {
            background-position-x: 1000px;
            }
        }

    </style>
</head>
<body>
    
    <div class="background">

    <!-- signup -->
    <div class="login">
        <div class="col-lg-4 col-md-8 col-sm-12 bg-white border rounded p-4 shadow-sm">
            <form method="post" action="assets/php/actions.php?signup">
                <div class="d-flex justify-content-center">

                    <img class="mb-4" src="assets\images\SereneLogo.png" alt="" height="150">
                </div>
                <h1 class="h5 mb-3 fw-normal">Create new account</h1>
                <div class="d-flex">
                    <div class="form-floating mt-1 col-6 ">
                        <input type="text" name="first_name" value="<?=showFormData('first_name')?>" class="form-control rounded-0" placeholder="username/email">
                        <label for="floatingInput">first name</label>
                    </div>
                    <div class="form-floating mt-1 col-6">
                        <input type="text" name="last_name" value="<?=showFormData('last_name')?>" class="form-control rounded-0" placeholder="username/email">
                        <label for="floatingInput">last name</label>
                    </div>
                </div>
                <?=showError('first_name')?>
                <?=showError('last_name')?>

                <div class="d-flex gap-3 my-3">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="exampleRadios1"
                            value="1" <?=isset($_SESSION['formdata'])?'':'checked'?><?=showFormData('gender')==1?'checked':''?>>
                        <label class="form-check-label" for="exampleRadios1">
                            Male
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="exampleRadios3"
                            value="2" <?=showFormData('gender')==2?'checked':''?>>
                        <label class="form-check-label" for="exampleRadios3">
                            Female
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="exampleRadios2"
                            value="0" <?=showFormData('gender')==0?'checked':''?>>
                        <label class="form-check-label" for="exampleRadios2">
                            Other
                        </label>
                    </div>
                </div>
                <div class="form-floating mt-1">
                    <input type="email" name="email" value="<?=showFormData('email')?>" class="form-control rounded-0" placeholder="username/email">
                    <label for="floatingInput">email</label>
                </div>
                <?=showError('email')?>

                <div class="form-floating mt-1">
                    <input type="text" name="username" value="<?=showFormData('username')?>" class="form-control rounded-0" placeholder="username/email">
                    <label for="floatingInput">username</label>
                </div>
                <?=showError('username')?>

                <div class="form-floating mt-1">
                    <input type="password" name="password" class="form-control rounded-0" id="floatingPassword" placeholder="Password">
                    <label for="floatingPassword">password</label>
                </div>
                <?=showError('password')?>


                <div class="mt-3 d-flex justify-content-between align-items-center">
                    <button class="btn btn-primary" type="submit">Sign Up</button>
                    <a href="?login" class="text-decoration-none">Have an existing account?</a>


                </div>

            </form>
        </div>
    </div>
    <!--footer-->
    <footer>
        <div class="waves">
        <div class="wave" id="wave1"></div>
        <div class="wave" id="wave2"></div>
        <div class="wave" id="wave3"></div>
        <div class="wave" id="wave4"></div>
        </div>
        <ul class="social_icon">
        <li><ion-icon name="heart-outline"></ion-icon></li>
        <li><ion-icon name="accessibility-outline"></ion-icon></li>
        <li><ion-icon name="people-circle-outline"></ion-icon></li>
        </ul>

        <ul class="menu">
        <li>Self-Care</li>
        <li>Share</li>
        <li>Support</li>
        <li>Strength</li>
        <li>Stability</li>
        </ul>
        <p>@2023 SereneScribe | Web Application | Year 3 </p>
    </footer>
        <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    </div>
    </body>
</html>
