<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <style>
    @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap");

    * {
        margin: 0;
        padding: 0;
    }

    /**-- background image --*/
    .background {
        background-image: url(assets/images/background.jpg);
        background-size: cover;
    }

    /**-- footer --**/
    footer {
        position: relative;
        width: cover;
        background: #3586ff;
        min-height: 200px;
        padding: 20px 50px;
        display: flex;
        justify-content: center;
        align-items: center;
        Flex-direction: column;
        margin-top: 0;
    }

    footer .social_icon,
    footer .menu {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 10px 0;
        flex-wrap: wrap;
    }
    footer .social_icon li,
    footer .menu li {
        list-style: none;
    }

    footer .social_icon li,
    footer .menu li {
        font-size: 2em;
        color: #fff;
        margin: 0 10px;
        display: inline-block;
        transition: 0.5s;
    }

    footer .social_icon li:hover {
        transform: translateY(-10px);
    }

    footer .menu li {
        font-size: 1.2em;
        color: #fff;
        margin: 0 10px;
        display: inline-block;
        text-decoration: none;
        opacity: 0.75;
    }

    footer .menu li:hover {
        opacity: 1;
    }

    footer p {
        color: #fff;
        text-align: center;
        margin-top: 15px;
        margin-bottom: 10px;
        font-size: 1.1em;
    }

    footer .wave {
        position: absolute;
        top: -100px;
        left: 0;
        width: 100%;
        height: 100px;
        background: url(images/wave.png);
        background-size: 1000px 100px;
    }

    footer .wave#wave1 {
        z-index: 1000;
        opacity: 1;
        bottom: 0;
        animation: animateWave 7s linear infinite;
    }

    footer .wave#wave2 {
        z-index: 999;
        opacity: 0.5;
        bottom: 10px;
        animation: animateWave_02 7s linear infinite;
    }

    footer .wave#wave3 {
        z-index: 1000;
        opacity: 0.2;
        bottom: 15px;
        animation: animateWave_02 5s linear infinite;
    }

    footer .wave#wave4 {
        z-index: 999;
        opacity: 0.7;
        bottom: 20px;
        animation: animateWave_02 5s linear infinite;
    }

    @keyframes animateWave {
        0% {
    background-position-x: 1000px;
        }
        100% {
    background-position-x: 0px;
        }
    }

    @keyframes animateWave_02 {
        0% {
    background-position-x: 0px;
        }
        100% {
        background-position-x: 1000px;
        }
    }
    </style>
</head>

<body>
    <div class="background">
    <!-- login -->
        <div class="login">
            <div class=" col-sm-12 col-md-4 bg-white border rounded p-4 shadow-sm" >
                <form method="post" action="assets/php/actions.php?login">
                    <div class="d-flex justify-content-center">

                        <img class="mb-4" src="assets/images/SereneLogo.png" alt="" height="150">
                    </div>
                    <h1 class="h5 mb-3 fw-normal">Please sign in</h1>

                    <div class="form-floating">
                        <input type="text" name="username_email" value="<?=showFormData('username_email')?>" class="form-control rounded-0" placeholder="username/email">
                        <label for="floatingInput">username/email</label>
                    </div>
                    <?=showError('username_email')?>
                    <div class="form-floating mt-1">
                        <input type="password" name="password" class="form-control rounded-0" id="floatingPassword" placeholder="Password">
                        <label for="floatingPassword">password</label>
                    </div>
                    <?=showError('password')?>
                    <?=showError('checkuser')?>


                    <div class="mt-3 d-flex justify-content-between align-items-center">
                        <button class="btn btn-primary" type="submit">Sign in</button>
                        <a href="?signup" class="text-decoration-none">Don't have an existing account?</a>


                    </div>
                </form>
            </div>
        </div>

        <!--footer-->
    <footer>
        <div class="waves">
        <div class="wave" id="wave1"></div>
        <div class="wave" id="wave2"></div>
        <div class="wave" id="wave3"></div>
        <div class="wave" id="wave4"></div>
        </div>
        <ul class="social_icon">
        <li><ion-icon name="heart-outline"></ion-icon></li>
        <li><ion-icon name="accessibility-outline"></ion-icon></li>
        <li><ion-icon name="people-circle-outline"></ion-icon></li>
        </ul>

        <ul class="menu">
        <li>Self-Care</li>
        <li>Share</li>
        <li>Support</li>
        <li>Strength</li>
        <li>Stability</li>
        </ul>
        <p>@2023 SereneScribe | Web Application | Year 3 </p>
    </footer>
        <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    </div>

    </body>
</html>

